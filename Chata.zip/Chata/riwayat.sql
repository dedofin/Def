-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2016 at 02:28 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chating`
--

-- --------------------------------------------------------

--
-- Table structure for table `riwayat`
--

CREATE TABLE `riwayat` (
  `pengirim` varchar(50) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `pesan` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `riwayat`
--

INSERT INTO `riwayat` (`pengirim`, `penerima`, `pesan`) VALUES
('dofin', 'all', 'boy'),
('dofin', 'all', 'boy'),
('adrian', 'all', 'apa woi'),
('adrian', 'all', 'apa woi'),
('dofin', 'all', 'java gmn ??'),
('dofin', 'all', 'java gmn ??'),
('adrian', 'all', 'ga sehat'),
('adrian', 'all', 'ga sehat'),
('dofin', 'all', 'wkwkkwk'),
('dofin', 'all', 'wkwkkwk'),
('animous', 'all', 'apaaa'),
('animous', 'all', 'apaaa'),
('animous', 'all', 'huehuehueh'),
('animous', 'all', 'huehuehueh'),
('animous', 'all', 'hihohooh'),
('animous', 'all', 'hihohooh');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
