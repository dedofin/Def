/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chat;

/**
 *
 * @author niko
 */
public class HistoryData {
 private String pengirim;
 private String penerima;
 private String pesan;

 public String getpengirim(){
return(pengirim);
}
 
 
 
 public String getpesan(){
     return (pesan);
 }
 
 public void setpengirim(String pengirim){
     this.pengirim = pengirim;
 }
 
 
 
 public void setpesan (String pesan){
     this.pesan = pesan;
 }
};


