

package chat;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;
import java.util.*;
import chat.ChatClient;


public class database {
    private Connection conn ;
    
    public database () throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/chating","root","");
    }
    
    public boolean isConnected() {
     return (conn != null);
    
    }
    
    
    public void inserthistory( String pengirim, String penerima, String pesan)
    throws Exception {
       String query = "INSERT INTO riwayat(pengirim, penerima, pesan) "
               + "VALUES (?,?,?)";
       
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, pengirim);
        stmt.setString(2, penerima);
        stmt.setString(3, pesan);
        stmt.execute();
        stmt.close();
       
    }
     
     

   public String selecthistory(String pengirim) throws SQLException {
       String pesan = ""; 
       
       String query = "SELECT * FROM riwayat ";
       
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery(query);
         while (rs.next()){
             pesan += rs.getString("pengirim")+" : "+ rs.getString("pesan")+"\n";
             System.out.println(pesan);
         }
         return pesan;
  }
}
